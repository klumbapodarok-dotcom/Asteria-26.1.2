-- lib reqs --
require("GSAnimBlend")
--also needs EZanims

function events.tick() --on each tick. 20/second
    --for variable wing flapping animation speed--
    local speed = vectors.vec3(math.abs(player:getVelocity()[1]),math.abs(player:getVelocity()[2]),math.abs(player:getVelocity()[3]))
    local totalspeed = speed[1]+speed[2]+speed[3]
    local velocityvirt= vectors.vec3(math.abs(player:getVelocity()[1]),player:getVelocity()[2],math.abs(player:getVelocity()[3]))
    local velocityvirtflat = velocityvirt[1]+velocityvirt[2]+velocityvirt[3] --cant do discreet math with a vector3 so i have this
    local blendweight = velocityvirtflat/2 
    local lookvirt = math.clamp(player:getLookDir()[2], 0, 1) --this is used to give extra flap at low speeds when looking up, make it look like you're properly taking off
    local flappyBlend = math.clamp(blendweight+lookvirt,0,1.5) --final blend weight math
    local flappySpeed = (velocityvirtflat*0.6)+lookvirt --final anim speed math
    if player:isGliding() then
        animations.model.flappy:play()
        --im doing contrails first fuck you--
        if totalspeed >= 1 then
            particles:newParticle("minecraft:mycelium",models.model.root.Body.leftwing.leftportion.leftelbow.leftpalm.leftfinger1.leftforefinger1.claw:partToWorldMatrix():apply())
            particles:newParticle("minecraft:mycelium",models.model.root.Body.rightwing.rightportion.rightelbow.rightpalm.rightfinger1.rightforefinger1.claw4:partToWorldMatrix():apply())
        else
        end
        animations.model.flappy:setBlend(flappyBlend)
        animations.model.flappy:setSpeed(flappySpeed)
    else
        animations.model.flappy:stop()
    end
end